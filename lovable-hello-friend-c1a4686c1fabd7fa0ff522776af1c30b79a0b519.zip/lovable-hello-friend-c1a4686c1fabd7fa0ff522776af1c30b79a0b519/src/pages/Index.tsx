
import { useState, useEffect } from "react";
import { 
  Leaf, BarChart, CloudRain, Users, Search, ChevronRight, 
  Mic, Sprout, LineChart, Settings, BellRing 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "@/components/ui/use-toast";
import { AgricultureDashboard } from "@/components/AgricultureDashboard";
import { 
  SidebarProvider, Sidebar, SidebarContent, SidebarHeader, 
  SidebarFooter, SidebarGroup, SidebarGroupLabel, 
  SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarTrigger 
} from "@/components/ui/sidebar";

const Index = () => {
  const [query, setQuery] = useState("");
  const [isLoaded, setIsLoaded] = useState(false);
  
  useEffect(() => {
    // Trigger animations after component mounts
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      toast({
        title: "Query Submitted",
        description: "Your agricultural query is being processed by our AI agents.",
      });
      // In a real application, this would connect to your multi-agent system
      setQuery("");
    }
  };

  return (
    <SidebarProvider defaultOpen={true}>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-[#F0F5F5] to-[#D7F2ED] dark:from-[#243E3E] dark:to-[#2A9D8F]/70">
        <Sidebar variant="sidebar">
          <SidebarHeader>
            <div className="flex items-center gap-2 px-2">
              <div className="p-1.5 rounded-full bg-[#D7F2ED] dark:bg-[#2A9D8F]/50">
                <Leaf className="h-5 w-5 text-[#2A9D8F] dark:text-[#D7F2ED] animate-pulse-slow" />
              </div>
              <h1 className="text-xl font-playfair font-bold text-[#2A9D8F]">AgroIntelligence</h1>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>Dashboard</SidebarGroupLabel>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton isActive={true} tooltip="Overview">
                    <BarChart className="h-4 w-4" />
                    <span className="font-poppins">Overview</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton tooltip="Analytics">
                    <LineChart className="h-4 w-4" />
                    <span className="font-poppins">Analytics</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton tooltip="Notifications">
                    <BellRing className="h-4 w-4" />
                    <span className="font-poppins">Alerts</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroup>
            
            <SidebarGroup>
              <SidebarGroupLabel>AI Agents</SidebarGroupLabel>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton tooltip="Soil Conditions Predictor">
                    <Sprout className="h-4 w-4" />
                    <span className="font-poppins">Soil Assistant</span>
                    <span className="ml-auto text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-100 px-1.5 rounded">SCP</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton tooltip="Voice AI Assistant">
                    <Mic className="h-4 w-4" />
                    <span className="font-poppins">Voice Assistant</span>
                    <span className="ml-auto text-xs bg-violet-100 text-violet-800 dark:bg-violet-900 dark:text-violet-100 px-1.5 rounded">VAA</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton tooltip="Weather Analyzer">
                    <CloudRain className="h-4 w-4" />
                    <span className="font-poppins">Weather Forecaster</span>
                    <span className="ml-auto text-xs bg-sky-100 text-sky-800 dark:bg-sky-900 dark:text-sky-100 px-1.5 rounded">WA</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton tooltip="Market Insights Analyzer">
                    <LineChart className="h-4 w-4" />
                    <span className="font-poppins">Market Analyst</span>
                    <span className="ml-auto text-xs bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 px-1.5 rounded">MIA</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroup>
            
            <SidebarGroup>
              <SidebarGroupLabel>Resources</SidebarGroupLabel>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton tooltip="Expert Network">
                    <Users className="h-4 w-4" />
                    <span className="font-poppins">Expert Network</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton tooltip="Settings">
                    <Settings className="h-4 w-4" />
                    <span className="font-poppins">Settings</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroup>
          </SidebarContent>
          <SidebarFooter>
            <div className="px-4 py-2 text-xs text-muted-foreground font-poppins">
              AgroIntelligence v1.2 • Multi-Agent System
            </div>
          </SidebarFooter>
        </Sidebar>
        
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto p-4 md:p-6">
            <header className={`flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10 transition-all duration-700 ${isLoaded ? 'opacity-100' : 'opacity-0 translate-y-4'}`}>
              <div>
                <div className="flex items-center">
                  <h1 className="text-3xl font-playfair font-bold text-[#2A9D8F]">
                    Multi-Agent Farm Intelligence
                  </h1>
                  <div className="ml-2 px-2 py-1 bg-[#D7F2ED] dark:bg-[#2A9D8F]/30 rounded-full text-xs text-[#2A9D8F] dark:text-[#D7F2ED] font-medium animate-pulse-slow">ACTIVE</div>
                </div>
                <p className="text-muted-foreground mt-1 font-poppins">
                  Integrated AI agents for optimal farming decisions
                </p>
              </div>
              
              <div className="flex items-center gap-2">
                <SidebarTrigger className="md:hidden" />
                <Button variant="outline" className="card-hover-effect">
                  <Search className="h-4 w-4 mr-1" />
                  Knowledge Base
                </Button>
                <Button className="card-hover-effect bg-gradient-to-r from-[#2A9D8F] to-[#243E3E] hover:from-[#279183] hover:to-[#1c3333]">
                  Connect Devices
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </header>
            
            <form onSubmit={handleSubmit} className={`mb-8 transition-all duration-700 delay-200 ${isLoaded ? 'opacity-100' : 'opacity-0 translate-y-4'}`}>
              <Card className="p-1 bg-white/80 dark:bg-[#243E3E]/80 backdrop-blur-sm">
                <div className="flex gap-2 p-2">
                  <Input 
                    placeholder="Ask any question to our farm AI agents (e.g., soil moisture levels, market prices, weather forecast)" 
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="border-[#D7F2ED] focus-visible:ring-[#2A9D8F] bg-transparent font-poppins"
                  />
                  <Button type="submit" className="bg-gradient-to-r from-[#2A9D8F] to-[#243E3E] hover:from-[#279183] hover:to-[#1c3333]">
                    Ask Agents
                  </Button>
                </div>
              </Card>
            </form>
            
            <div className={`transition-all duration-700 delay-300 ${isLoaded ? 'opacity-100' : 'opacity-0 translate-y-4'}`}>
              <AgricultureDashboard />
            </div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
};

export default Index;
